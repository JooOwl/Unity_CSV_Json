# UnityCsvUtilExample
Example of UnityCsvUtil for Unity User

I inspired "Unity simple CSV/object serialiser" for unit from sinbad/UnityCsvUtil (https://github.com/sinbad/UnityCsvUtil)
But there is nothing enough for helping to use that useful code int Unity3d. 
Therefore, I made some example of that serializer for easy to use.

## How to use

Let's say we have an object with public fields, e.g.

```c#
    RunExample1("happy");	// simple way
    RunExample2("happy");	// another way using find ( referencing way )
    RunExample3(13);	// 13 is id & direct way using exact number that already knew
    RunExampleSaveLoad();

```

```c#
    void RunExample1(string input) {
        // 1. check include word (Simple way)
        if(CsvLoader.instance._greetingWords[input].WordsArray.Contains("peaceful")) {
            Debug.Log(input+" included peachful word");
        }
        Debug.Log(CsvLoader.instance._greetingWords["hello"].Words);
    }
```

```c#
    void RunExample2(string input) {
        // a way to get item ( you don't know exact id from the value)
        var find = CsvLoader.instance._defaultValue.Values.FirstOrDefault( va => va.StrValue == input);
        if(find == default(DefaultValue))
            Debug.Log("not found " + input);

        // same result but another way
        find = CsvLoader.instance._defaultValue[12];	// 12 is id that you write on

        if(CsvLoader.instance._greetingWords[find.StrValue].WordsArray.Contains("peaceful")) {
            Debug.Log(find.id + " included peachful word," + find.StrValue);
        }

        Debug.Log(find.id);
        Debug.Log(find.StrValue);
    }		
```

```c#
    void RunExample3(int id) {
        // same result but another way
        var find = CsvLoader.instance._defaultValue[id];	// id that you write on

        if(CsvLoader.instance._greetingWords[find.StrValue].WordsArray.Contains("peaceful")) {
            Debug.Log(find.id + " included peachful word," + find.StrValue);
        }

        Debug.Log(find.id);
        Debug.Log(find.StrValue);

    }		
```

CSV data 

```c#

id,Value,StrValue
10,10000,hello
11,70,angry
12,0,happy
13,10000,suck
14,0,neglected
15,250,test

```


```c#

Key,Cost,Word1,Word2,Word3,Words
hello,10000,Anytime,Anywhere,Anyhow,"good morning,good afternoon,good evening,hi,hello,what's up,bye"
angry,10000,Anytime,Anywhere,Anyhow,"bitter,heated,cross,hot"
happy,10000,Anytime,Anywhere,Anyhow,"glad,peaceful,contented"
suck,10000,Anytime,Anywhere,Anyhow,"draw,nurse,water,drink"
neglected,10000,Anytime,Anywhere,Anyhow,"ignored,abandoned,overlooked"
test,10000,Anytime,Anywhere,Anyhow,"test,abc,ddd,asd"

```

The CsvLoader class is that I made. It is for easily loading and using data. First part instance is the singleton pattern and there are variables & data class for loading from CSV file. These are added variables that you have to add when you want. You should add like that by yourself manually.

## Acknowledgements

The regex for CSV splitting comes from [CSVReader](http://wiki.unity3d.com/index.php?title=CSVReader)
on the Unity wiki.

CsvUtil, Unity simple CSV/object serialiser comes from [inbad/UnityCsvUtil](https://github.com/sinbad/UnityCsvUtil) on the Github.
