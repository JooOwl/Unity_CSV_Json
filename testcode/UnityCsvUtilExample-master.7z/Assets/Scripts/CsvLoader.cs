﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace R {

	using Sinbad;
	public class CsvLoader {

		static CsvLoader _instance;

		public static CsvLoader instance {
			get { 
				if(_instance == null) {
					_instance = new CsvLoader();
					_instance.LoadAll("Assets/Resources/");
				}
				return _instance;
			}
		}

		public Dictionary<string, GreetingWords> _greetingWords;
		public Dictionary<int, DefaultValue> _defaultValue;

		bool LoadAll(string path) {

			// load & make a table with GreetingWords csv
			var loadGreetingWords = CsvUtil.LoadObjects<GreetingWords>(path+"TestDataForCSV - GreetingWords.csv");
			_greetingWords = new Dictionary<string, GreetingWords>();	
			for(int i=0;i<loadGreetingWords.Count;i++) {
				_greetingWords.Add(loadGreetingWords[i].Key, loadGreetingWords[i]);
			}

			// load & make a table with defaultValue csv
			var LoadDefault = CsvUtil.LoadObjects<DefaultValue>(path+"TestDataForCSV - DefaultValue.csv");
			_defaultValue = new Dictionary<int, DefaultValue>();	
			foreach(var info in LoadDefault)
				_defaultValue.Add(info.id, info);
			

			return true;
		}


	}

	// for default table
	public class DefaultValue {
		public int id;	// came from csv header
		public float Value;	// came from csv header
		public string StrValue;	// came from csv header
	}

	// for enum table
	public class GreetingWords {
		public string Key;	// came from csv header
		public int Cost;	// came from csv header
		public string Word1;	// came from csv header
		public string Word2;	// came from csv header
		public string Word3;	// came from csv header
		public string Words;	// came from csv header

		// extended function ( custom added ) -------- for using group words
		List<string> _WordsArray = null;
		public List<string> WordsArray {
			get{
				if(_WordsArray == null)
					_WordsArray = new List<string>(Words.Split(','));
				return _WordsArray;
			}
		}

	}

	public class MyObject {
		public string Name;
		public int Level;
		public float Dps;
		public enum Colour {
			Red = 1,
			Green = 2,
			Blue = 3,
			Black = 4,
			Purple = 15
		}
		public Colour ShirtColour;

		public MyObject() {

		}
		public MyObject(string _name, int _level, float _dsp, Colour _color) {
			this.Name = _name;
			this.Level = _level;
			this.Dps = _dsp;
			this.ShirtColour = _color;
		}

		public override string ToString() {
			return Name+","+Level+","+Dps+","+ShirtColour;
		}
	}
}
