﻿using UnityEngine;
using System.Collections;

public class AndroidButten : MonoBehaviour {

	DisableSystemUI systemUI = null;

	void Awake()
	{
		DontDestroyOnLoad (this);
	}

	// Use this for initialization
	void Start () 
	{
#if UNITY_ANDROID
		if (Application.platform != RuntimePlatform.Android)
			return;
		
		systemUI = new DisableSystemUI();
		systemUI.DisableNavUI();

		StartCoroutine("SystemUIRun");
#endif
	}
		
	// Update is called once per frame
	// 안드로이드 백 버튼 관련 수정
	void Update () 
	{
#if UNITY_ANDROID
		if (Application.platform == RuntimePlatform.Android) 
		{
			if (Input.GetKey (KeyCode.Home)) 
			{
				//home button
			} 
			else if (Input.GetKey (KeyCode.Escape)) 
			{
				//back button
				SceneControlManager.myInstance.StackPop();
			} 
			else if (Input.GetKey (KeyCode.Menu)) 
			{
				//menu button
			}
		}
#endif
	}

	// 시스템 코루틴 소프트키 없애는 코드
	IEnumerator SystemUIRun()
	{
#if UNITY_ANDROID
		while(true)
		{
			yield return new WaitForSeconds(1f);

			systemUI.Run();
		}
#else
		yield break;
#endif
	}

	// 화면 나갔다 오면 다시 없애는 코드
	void OnApplicationFocus()
	{
#if UNITY_ANDROID
		if (Application.platform != RuntimePlatform.Android)
			return;
		
		systemUI.DisableNavUI();
		systemUI.Run();
#endif
	}
}
