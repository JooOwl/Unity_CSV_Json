﻿using UnityEngine;
using System.Collections.Generic;
using System;
using System.Collections;

public class SDebugLog : MonoBehaviour {

	static List<string> mLines = new List<string>();

	static bool mRayDebug = false;
	static public void LogClear () { mLines.Clear(); }
	static SDebugLog mInstance = null;

	static public bool debugRaycast
	{
		get
		{
			return mRayDebug;
		}
		set
		{
			if (Application.isPlaying)
			{
				mRayDebug = value;
				if (value) CreateInstance();
			}
		}
	}

	static public void LogError (params object[] objs)
	{
		string text = "";

		for (int i = 0; i < objs.Length; ++i)
		{
			if (i == 0)
			{
				text += objs[i].ToString();
			}
			else
			{
				text += ", " + objs[i].ToString();
			}
		}

		Debug.LogError (text);
	}

	void ClearToTime()
	{
		mLines.Clear();
	}

	static public void LogView (params object[] objs)
	{
		string text = "";
		
		for (int i = 0; i < objs.Length; ++i)
		{
			if (i == 0)
			{
				text += objs[i].ToString();
			}
			else
			{
				text += ", " + objs[i].ToString();
			}
		}
		LogString(text);
	}

	static void LogString (string text)
	{
		if (Application.isPlaying)
		{
			if (mLines.Count > 30) mLines.RemoveAt(0);
			mLines.Add(text);
			CreateInstance();

			Debug.Log(text);
		}
		else Debug.Log(text);

		if( mInstance != null)
		{
			mInstance.CancelInvoke ( "ClearToTime" );
			mInstance.Invoke( "ClearToTime", 60f);
		}
	}

	static public void CreateInstance ()
	{
		if (mInstance == null)
		{
			GameObject go = new GameObject("_SDebug_Log");
			mInstance = go.AddComponent<SDebugLog>();
			DontDestroyOnLoad(go);
		}
	}

	void OnGUI()
	{
		if (mLines.Count == 0)
		{
			if (mRayDebug && UICamera.hoveredObject != null && Application.isPlaying)
			{
				GUILayout.Label("Last Hit: " + NGUITools.GetHierarchy(UICamera.hoveredObject).Replace("\"", ""));
			}
		}
		else
		{
			for (int i = 0, imax = mLines.Count; i < imax; ++i)
			{
				GUILayout.Label(mLines[i]);
			}
		}
	}
}
